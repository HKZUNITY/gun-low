import { ConfigBase, IElementBase } from "./ConfigBase";
const EXCELDATA:Array<Array<any>> = [["ID","TRAILING","PRICETYPE","PRICE","NAME","DESC"],["","","","","Language",""],[1,"14317",1,[1,8888],"SmokeTrail","烟雾拖尾"],[2,"14319",1,[1,8888],"SmokeTrail","烟雾拖尾"],[3,"27399",1,[1,8888],"SmokeTrail","烟雾拖尾"],[4,"27447",1,[1,8888],"ParticleTailing","粒子拖尾"],[5,"30497",1,[1,8888],"SmokeTrail","烟雾拖尾"],[6,"88020",1,[1,8888],"BeamTrailing","光束拖尾"],[7,"88442",1,[1,8888],"BeamTrailing","光束拖尾"],[8,"88443",1,[1,8888],"BeamTrailing","光束拖尾"],[9,"88796",1,[1,8888],"SmokeTrail","烟雾拖尾"],[10,"88794",1,[1,8888],"SmokeTrail","烟雾拖尾"],[11,"88797",1,[1,8888],"SmokeTrail","烟雾拖尾"],[12,"88798",1,[1,8888],"SmokeTrail","烟雾拖尾"],[13,"89592",1,[1,8888],"BeamTrailing","光束拖尾"],[14,"128512",1,[1,8888],"BeamTrailing","光束拖尾"],[15,"128513",1,[1,8888],"BeamTrailing","光束拖尾"],[16,"128514",1,[1,8888],"BeamTrailing","光束拖尾"],[17,"128515",1,[1,8888],"BeamTrailing","光束拖尾"],[18,"128516",1,[1,8888],"BeamTrailing","光束拖尾"],[19,"128517",1,[1,8888],"BeamTrailing","光束拖尾"],[20,"128518",1,[1,8888],"BeamTrailing","光束拖尾"],[21,"146783",1,[1,8888],"SmokeTrail","烟雾拖尾"],[22,"148710",1,[1,8888],"Tail","拖尾"],[23,"150907",1,[1,8888],"WaterTailing","水拖尾"],[24,"145511",1,[1,8888],"FlameTrailing","火焰拖尾"],[25,"151527",1,[1,8888],"SmokeTrail","烟雾拖尾"],[26,"151528",1,[1,8888],"SmokeTrail","烟雾拖尾"],[27,"153603",1,[1,8888],"Tail","拖尾"],[28,"153613",1,[1,8888],"Tail","拖尾"],[29,"128519",1,[1,8888],"BeamTrailing","光束拖尾"],[30,"128520",1,[1,8888],"BeamTrailing","光束拖尾"],[31,"145496",1,[1,8888],"SmokeTrail","烟雾拖尾"],[32,"145506",1,[1,8888],"Tail","拖尾"],[33,"128521",1,[1,8888],"BeamTrailing","光束拖尾"],[34,"4399",1,[1,8888],"ThunderTail","雷拖尾"],[35,"27392",1,[1,8888],"RainbowTail","彩虹拖尾"],[36,"133481",1,[1,8888],"TirePrintTailing","胎印拖尾"],[37,"145492",1,[1,8888],"ScrewTail","螺丝钉拖尾"],[38,"145493",1,[1,8888],"FootballTail","足球拖尾"],[39,"145494",1,[1,8888],"RainbowTail","彩虹拖尾"],[40,"145495",1,[1,8888],"CandyTail","糖果拖尾"],[41,"145497",1,[1,8888],"TrophyTail","奖杯拖尾"],[42,"145498",1,[1,8888],"CrownTail","皇冠拖尾"],[43,"145499",1,[1,8888],"LoveTail","爱心拖尾"],[44,"145500",1,[1,8888],"SkullTail","骷髅拖尾"],[45,"145502",1,[1,8888],"BananaTail","香蕉拖尾"],[46,"145503",1,[1,8888],"ThunderTail","雷电拖尾"],[47,"145504",1,[1,8888],"SnowflakeTail","雪花拖尾"],[48,"145505",1,[1,8888],"Tail2023","2023拖尾"],[49,"145507",1,[1,8888],"FirecrackerTail","爆竹拖尾"],[50,"145508",1,[1,8888],"FireworksTail","烟花拖尾"],[51,"145509",1,[1,8888],"GiftTail","礼物拖尾"],[52,"145510",1,[1,8888],"TailOfBanknotes","钞票拖尾"],[53,"145512",1,[1,8888],"BubbleTail","泡泡拖尾"],[54,"145513",1,[1,8888],"RibbonTrailing","彩带拖尾"],[55,"186344",1,[1,8888],"TailOfFeces","便便拖尾"],[56,"195115",1,[1,8888],"MapleLeafTail","枫叶拖尾"],[57,"196217",1,[1,8888],"SixPointedStarTail","六芒星拖尾"],[58,"221186",1,[1,8888],"ButterflyTail","蝴蝶拖尾"],[59,"221187",1,[1,8888],"IceCreamTrail","冰淇淋拖尾"],[60,"267975",1,[1,8888],"BirdTail","鸟拖尾"],[61,"271639",1,[1,8888],"BatTail","蝙蝠拖尾"],[62,"289528",1,[1,8888],"XiangyunTail","祥云拖尾"],[63,"290033",1,[1,8888],"Print","爪印"]];
export interface ITRAILINGElement extends IElementBase{
 	/**唯一ID*/
	ID:number
	/**拖尾Guid*/
	TRAILING:string
	/**0-免费
1-金币|钻石
2-钻石*/
	PRICETYPE:number
	/**价格
钻石|金币*/
	PRICE:Array<number>
	/**名字*/
	NAME:string
	/**名字*/
	DESC:string
 } 
export class TRAILINGConfig extends ConfigBase<ITRAILINGElement>{
	constructor(){
		super(EXCELDATA);
	}

}