﻿import MallData from "./MallData";
import MallModuleC from "./MallModuleC";

export default class MallModuleS extends ModuleS<MallModuleC, MallData> {

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {

    }
}