﻿export enum EventType {
    /**打开关闭（主控UI-HUD、Radar、Weapon） */
    OnOffMainHUD = "OnOffMainHUD",
    TryOutGun = "TryOutGun",
    OnOffWeaponUI = "OnOffWeaponUI",
}